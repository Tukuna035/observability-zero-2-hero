# OpenSearch Stack 

### Prerequisites

- Setup a Kubernetes cluster
- Create the logging namespace - `kubectl create ns logging`
- Create serviceaccount in the namespace - `kubectl create sa fluent-bit -n logging`

